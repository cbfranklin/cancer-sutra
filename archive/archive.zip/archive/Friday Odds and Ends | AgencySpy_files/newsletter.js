function AjaxFormField(element, $) {
    var self = {};
    self.f$ = null;
    self.is_required = false;
    self.placeholder = null;
    self.error_message = '';
    self.placeholder_support = false;

    self.init = function(field) {
        self.f$ = $(field);
        self.is_required = self.f$.hasClass('required');
        self.is_email = self.f$.hasClass('email');
        self.error_message = self.f$.attr('data-error') || '';
        self.placeholder_support = ("placeholder" in document.createElement('input'));

        if (!self.placeholder_support) {
            self.show_placeholder(self.f$);
    
            self.f$.focus(function() {
                if (self.f$.val() == self.placeholder) {
                    self.f$.context.setSelectionRange(0, 0);
                }
            });
    
            self.f$.keydown(function() {
                self.hide_placeholder(self.f$);
            });
    
            self.f$.blur(function() {
                if (self.f$.val() == '') {
                    self.show_placeholder(self.f$);
                }
            });
        };
    };

    self.hide_placeholder = function(field$) {
        if (field$.val() == self.placeholder) {
            self.unmute();
            field$.val('');
        }
    };

    self.show_placeholder = function(field$) {
        if (self.placeholder != undefined) {
            self.mute();
            field$.val(self.placeholder);
        }
    };

    self.mute = function() {
        self.f$.addClass('muted');
    };

    self.unmute = function() {
        self.f$.removeClass('muted');
    };

    self.is_email_valid = function(email) {
        if(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(self.f$.val()))
            return true;
        else
            return false;
    };

    self.is_valid = function(field$) {
        self.error_message = "";
        var err;
        //Check if a value was entered
        if (self.is_required) {
            if ($.trim(self.f$.val()) == '') {
                self.f$.addClass('input-error');
                err = self.f$.attr('data-error-required') || 'Validation Failed.';
                self.error_message += err;
                return false;
            }
        }
        //Check for email field and if so check if email is valid
        if (self.is_email) {
            if(!self.is_email_valid(self.f$.val())) {
                self.f$.addClass('input-error');
                err = self.f$.attr('data-error-email') || 'Validation Failed.';
                self.error_message += err;
                return false;
            }
        }

        return true;
    };

    self.init(element);
    return self;
}


function AjaxFormMessenger(div, $) {
    var self = {};
    self.el$ = null;
    self.original_classes = [];

    self.init = function(div) {
        self.el$ = $(div);
        self.original_classes = self.el$.attr('class').split(/\s+/);
    };

    self.notice = function(cls, str) {
        var s = self.el$.attr('data-' + cls);
        if (s) {
            self.el$.html(s);
        }
        self.addClass('alert-' + cls);
    };

    self.html = function(str) {
        self.el$.html(str);
    };
    
    self.addClass = function(cls) {
        var clses = self.original_classes.join(' ') + ' ' + cls;
        self.el$.attr('class', clses);
    };

    self.init(div);
    return self;
}

function AjaxForm(form, $) {
    
    var self = {};

    self.form$ = null;
    self.messenger = null;
    self.MESSENGER_CLS = 'messenger';
    self.fields = [];
    self.error_messages = [];

    self.init = function(form) {

        self.form$ = $(form);
        self.messenger = AjaxFormMessenger(_messenger(), $);
        self.hidden_on_success = self.form$.hasClass("hide-on-success");
        self.form$.find('[type="submit"]').click(function(ev) {
            ev.preventDefault();
            self.submit();
        });

        $(['input', 'textarea']).each(function(i, el) {
            self.form$.find(el).each(function(i, e) {
                self.fields.push(AjaxFormField(e, $));
            });
        });
    };

    self.is_valid = function() {
        var r = true;
        self.error_messages = [];

        $(self.fields).each(function(i, e) {
            if (!e.is_valid()) {
                self.error_messages.push(e.error_message);
                r = false;
            }
            else {
                if(e.f$.hasClass('input-error'))
                    e.f$.removeClass('input-error');
            }
        });

        return r;
    };

    self.submit = function() {

        if (self.is_valid()) {
            $.ajax({
                url: self.form$.attr('action'),
                data: self.form$.serialize(),
                type: 'POST',
                crossDomain: true,
                success: self.on_success,
                error: self.on_error,
                dataType: 'json',
                headers: {'Accept' : 'application/json'}
            });
        } else {
            self.on_error();
        }
    };

    self.on_success = function(data, status, xhr) {
        if(data.error) { 
            self.on_error(xhr, status, data); 
            return false; 
        }
        var s = self.messenger.el$.attr('data-success') || data.success || 'Submission successful.';
        self.messenger.addClass('alert-success');
        self.messenger.html(s);
        self.messenger.el$.show();

        if(self.hidden_on_success){
            $(self.fields).each(function(i, e) {
                e.f$.hide();
            });
            self.form$.find('button').each(function(i, e) {
                $(e).hide();
            });
        }
        else{
            $(self.fields).each(function(i, e) {
                if(e.f$.attr("type") == "text")
                    e.f$.val('');
            });
        }
    };

    self.on_error = function(xhr, status, err) {
        var s = "<ul>";
        if(self.error_messages.length > 0){
            for(var i = 0; i < self.error_messages.length; i++)
                s += self.error_messages[i];
        }
        else if(err)
            s += "<li>" + err.error || "Your message could not be sent." + "</li>";
        else if(!err || err === "")
            s += "<li>Sorry, we are unable to process your request at this time.  Please try again later.</li>";
        else
            s += "<li>" + self.messenger.el$.attr('data-error') || "Validation failed." + "</li>";
        s += "</ul>";
        self.messenger.addClass('alert-error');
        self.messenger.html(s);
        self.messenger.el$.show();
        $(self.fields).each(function(i, e) {
            if(e.f$.hasClass('input-error')){
                e.f$.focus();
                return false;
            }
        });
    };

    var _get_messenger = function() {
        var tmp = self.form$.find('.' + self.MESSENGER_CLS);
        if (tmp.length > 0)
            return tmp[0];
        else
            return null;
    };

    var _build_messenger = function(cls) {
        var s = '<div class="' + cls + '"></div>';
        self.form$.prepend(s);
    };

    var _messenger = function() {
        var r;
        if (!(r = _get_messenger())) {
            _build_messenger(self.MESSENGER_CLS);
            r = _get_messenger();
        }
        return r;
    };

    self.init(form);
    return self;
}

// __main__
(function($) {
    $(function() {

        $('.ajax-form').each(function(i, e) {

            var f = AjaxForm(this, $);

            // Override error functionality.
            // f.on_error = function (xhr, status, err) { ... }
        });
    });
})(jQuery);

jQuery(document).ready(function() {
    jQuery('#newsletterText').focus(function() {
        jQuery('.reg-options').show();
    });
});
