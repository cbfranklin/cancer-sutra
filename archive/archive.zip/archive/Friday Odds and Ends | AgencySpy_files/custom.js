jQuery(document).ready(function(e){
	// Sidr: mobile sidebar nav
	jQuery(".sidr-link").sidr({
      name: "sidr-existing-content",
      source: "#x-navbar-sidr"
    });

    e(window).resize(function() { 
    	jQuery.sidr("close", "sidr-existing-content");
    });
	
	// Desktop popover search box
    doc = e("document");
    snav = e(".x-navbar-inner .search-nav");
    tr = e(".search-nav-trigger");
    fr = e(".search-nav-frame");
    xnav = e(".x-nav-collapse");
    
    e(window).scroll(function(f) { 
    	snav.hide();
        xnav.removeClass("hidden");
        tr.removeClass("enabled");
        fr.removeClass("search-nav-frame-extended");
    });
    
    // Close search or Sidr if clicking outside the search boxes.
    e(document).click(function (f) {
	    if (e(f.target).closest(".search-nav-frame").length === 0 && 
	    e(f.target).closest(".sidr-class-search-query").length === 0 ||  
	    e(f.target)[0] == e(".search-nav-trigger.enabled")[0]) {
	        snav.hide();
	        xnav.removeClass("hidden");
	        tr.removeClass("enabled");
	        fr.removeClass("search-nav-frame-extended");
	    	jQuery.sidr("close", "sidr-existing-content");  
	    } else {	
	        snav.show();
	        xnav.addClass("hidden");
	        tr.addClass("enabled");
	        fr.addClass("search-nav-frame-extended");
        }
    });
    
    // Top social bar for post page--displays after page scroll passes social within the content area
    if (e("body").hasClass("single")) {
        soc = e(".x-custom-social")
	    cTop = e("#social-context").offset().top; 
	    e(window).scroll(function() { //when window is scrolled
		    if(cTop - e(window).scrollTop() < 0) {
		        soc.show();
		        e(".addthis_count_pop").html(e(".addthis_count").html());
		    } else {
		        soc.hide();
		    };
		});    	
	}
	
	addtop = e("#socialbar .addthis_button")
	addtop.mouseover(function(){
		jQuery("body").addClass("top-social-pop");
		jQuery("body").removeClass("cont-social-pop");
	});
	addcont = e(".entry-wrap .addthis_button")
	addcont.mouseover(function(){
		jQuery("body").removeClass("top-social-pop");
		jQuery("body").addClass("cont-social-pop");
	});
	
	// Show prev/next buttons if not empty
	jQuery( "#goprevious, #gonext" ).has( "a" ).addClass( "button" );
	
	// Add mobile sidebar background styles
	jQuery(".widget").has("div .wpcf7").addClass("mobileshaded");
	jQuery(".widget").has("div .ajax-form").addClass("mobileshaded");

	//Toggle mobile footer elements
	jQuery('.mobile-footer .network-footer ul').addClass("hidden");
	jQuery('.mobile-footer .about-footer h3, .mobile-footer .more-footer h3, .mobile-footer .network-footer h3').click(function(){
		jQuery(this).siblings('ul').toggleClass("hidden");
		jQuery(this).parent().toggleClass("toggleopen");
		
	})

	// vertically center floating prev/next arrows 
	jQuery('#swprevtrigger,#swnexttrigger').css('top',(jQuery(window).height() -100)/2)

    jQuery('.wpcf7-textarea').focus(function() {
        jQuery('.tipscaptcha').show();
    });

    jQuery('.wpcf7-textarea').on('input', function() {
        jQuery('.tipscaptcha').show();
    });

});

!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
