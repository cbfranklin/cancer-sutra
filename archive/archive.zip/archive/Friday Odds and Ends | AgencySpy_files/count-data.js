var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"and","comments":{"zero":"Comment","multiple":"{num} Comments","one":"1 Comment"}},"counts":[{"id":"http:\/\/www.adweek.com\/agencyspy\/friday-odds-and-ends-241\/85734","comments":0}]});
}