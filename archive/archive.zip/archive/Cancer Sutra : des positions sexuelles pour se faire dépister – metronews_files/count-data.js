var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"et","comments":{"zero":"0 ","multiple":"{num}","one":"1 "}},"counts":[{"id":"\/x\/metro\/2015\/05\/01\/DJUeE3tyeXSww\/index.xml","comments":0}]});
}